/******************* GLOBAL VARIABLES **********************/
extern FILE* glob_fp[MAX_FILE_NUM];
