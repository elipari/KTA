I file

A2_glob_file.be.c
A2_glob_file.le.c

sono stati sostituiti da

A2_glob_file.c

definendo la macro -DINTEL su macchine ieee-le

Febbraio 2002 - G. Bernasconi
